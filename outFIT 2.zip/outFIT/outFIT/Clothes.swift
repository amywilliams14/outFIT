//
//  Clothes.swift
//  outFIT
//
//  Created by Amy Williams on 11/21/21.
//

import Foundation
import UIKit

struct Clothes: Codable {
    var id: Int
    var url: String
    var top: Bool
}


//extension Clothes: Sequence {
//    func makeIterator() -> Array<Clothes>.Iterator {
//        return Clothes.makeIterator()
//    }
//}


